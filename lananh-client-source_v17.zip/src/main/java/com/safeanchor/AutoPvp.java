package com.safeanchor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;

/** Tự PvP: nhắm, đuổi, đánh theo cooldown; bật cùng Auto Crystal thì tự đặt/nổ crystal quanh mục tiêu. */
public class AutoPvp {
    static boolean held;

    public static void toggle(MinecraftClient mc) {
        Config.I.autoPvp = !Config.I.autoPvp; Config.save();
        if (!Config.I.autoPvp) release(mc);
        Util.msg("Auto PvP: " + (Config.I.autoPvp ? "§aBẬT" : "§cTẮT"));
    }
    static void release(MinecraftClient mc) {
        if (held) { mc.options.forwardKey.setPressed(false); mc.options.sprintKey.setPressed(false); held = false; }
    }
    static boolean weapon(ItemStack s) { return s.isOf(Items.MACE) || s.isIn(ItemTags.SWORDS) || s.isIn(ItemTags.AXES); }

    public static void tick(MinecraftClient mc) {
        Config c = Config.I; var p = mc.player;
        if (!c.autoPvp || !c.enabled || p == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) { release(mc); return; }
        if (c.autoTotem) Util.autoTotem();
        PlayerEntity t = Util.nearestEnemy(Math.max(10, c.pvpRange + 6));
        if (t == null) { release(mc); return; }
        if (c.pvpCrystal) { c.crystal = true; }
        if (!weapon(p.getMainHandStack())) Util.selectItem(AutoPvp::weapon);
        // xoay mượt về phía đối thủ
        float[] a = Aimbot.angles(mc, t.getPos().add(0, t.getHeight() * 0.65, 0));
        float s = (float) MathHelper.clamp(c.pvpSmooth, 0.1, 1.0);
        if (!c.pvpSilent) {
            p.setYaw(p.getYaw() + MathHelper.wrapDegrees(a[0] - p.getYaw()) * s);
            p.setPitch(MathHelper.clamp(p.getPitch() + (a[1] - p.getPitch()) * s, -90f, 90f));
        }
        double dist = Util.distToBox(p.getEyePos(), t.getBoundingBox());
        if (c.pvpWalk) {
            mc.options.forwardKey.setPressed(dist > c.pvpRange - 0.8);
            mc.options.sprintKey.setPressed(dist > c.pvpRange);
            if (p.horizontalCollision && p.isOnGround()) p.jump();
            held = true;
        }
        if (dist <= c.pvpRange && p.getAttackCooldownProgress(0.5f) >= 0.95f && p.canSee(t)) {
            if (c.pvpSilent) Util.sendLook(a[0], a[1]);
            mc.interactionManager.attackEntity(p, t); p.swingHand(Hand.MAIN_HAND);
            if (c.pvpSilent) Util.sendLook(p.getYaw(), p.getPitch());
            AutoCrystal.hitTarget = t; AutoCrystal.hitTicks = 60;
        }
    }
}
