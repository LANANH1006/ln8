package com.safeanchor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.function.IntConsumer;

/** Bấm 1 phím để gán phím tắt (Esc = hủy, Backspace/Delete = xóa phím). */
public class KeyCaptureScreen extends Screen {
    final Screen parent; final IntConsumer onKey;

    public KeyCaptureScreen(Screen parent, IntConsumer onKey) {
        super(Text.literal("Gán phím"));
        this.parent = parent; this.onKey = onKey;
    }

    @Override public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 256) { MinecraftClient.getInstance().setScreen(parent); return true; }
        if (keyCode == 259 || keyCode == 261) onKey.accept(-1); else onKey.accept(keyCode);
        MinecraftClient.getInstance().setScreen(parent);
        return true;
    }

    @Override public void render(DrawContext ctx, int mx, int my, float d) {
        ctx.fill(0, 0, width, height, 0xE00B0B14);
        ctx.drawCenteredTextWithShadow(textRenderer, "Bấm 1 phím để gán cho module này", width / 2, height / 2 - 12, 0xFFFFFFFF);
        ctx.drawCenteredTextWithShadow(textRenderer, "Esc = hủy  •  Backspace / Delete = xóa phím", width / 2, height / 2 + 4, 0xFFAAAAAA);
    }
}
