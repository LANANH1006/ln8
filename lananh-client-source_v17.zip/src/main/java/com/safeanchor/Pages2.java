package com.safeanchor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/** Các trang cài đặt cho tính năng mới (v2.3). */
public class Pages2 {
    static Config C() { return Config.I; }
    static MinecraftClient mc() { return MinecraftClient.getInstance(); }

    static Screen pvp(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(Pages.toggle("Auto PvP (phím V)", () -> C().autoPvp, v -> { if (v != C().autoPvp) AutoPvp.toggle(mc()); }));
        m.add(Pages.toggle("Tự bật Auto Crystal/Anchor khi PvP", () -> C().pvpCrystal, v -> C().pvpCrystal = v));
        m.add(Pages.toggle("Tự chạy tới đối thủ", () -> C().pvpWalk, v -> C().pvpWalk = v));
        m.add(Pages.toggle("Tự đổi totem", () -> C().autoTotem, v -> C().autoTotem = v));
        m.add(Pages.slider("Tầm đánh", 2.5, 6, false, () -> C().pvpRange, v -> C().pvpRange = v));
        m.add(Pages.slider("Độ mượt xoay (thấp = mượt)", 10, 100, true, () -> C().pvpSmooth * 100, v -> C().pvpSmooth = v / 100.0));
        m.add(Pages.toggle("Auto Crystal", () -> C().crystal, v -> C().crystal = v));
        m.add(Pages.toggle("Safe Anchor", () -> C().anchor, v -> C().anchor = v));
        return new MenuScreen("Auto PvP", p, m);
    }

    static Screen mine(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(Pages.toggle("Tự đào (phím N)", () -> C().mineOn, v -> { if (v != C().mineOn) AutoMine.toggle(mc()); }));
        m.add(Pages.slider("Tầm tìm block (block)", 6, 24, true, () -> C().mineRange, v -> C().mineRange = v));
        m.add(Pages.button("🔍 Thêm block cần đào (gõ \"ore\" -> hiện hết, có hình)", () -> Pages.open(p2 -> new PickScreen(p2, "Chọn block cần đào - chạm để thêm / bỏ", false, C().mineList, null))));
        for (String id : new ArrayList<>(C().mineList))
            m.add(Pages.button("❌ Bỏ: " + id, () -> { C().mineList.remove(id); Config.save(); mc().setScreen(mine(p)); }));
        return new MenuScreen("Tự đào", p, m);
    }

    static Screen ah(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(Pages.toggle("Auto /ah mua", () -> C().ahOn, v -> C().ahOn = v));
        TextFieldWidget[] kw = new TextFieldWidget[1], pr = new TextFieldWidget[1];
        m.add(Pages.button("🔍 Chọn món có hình (gõ \"dia\" -> hiện hết)", () -> Pages.open(p2 -> new PickScreen(p2, "Chọn món cho /ah - chạm để chọn", true, null, id -> {
            net.minecraft.util.Identifier i = net.minecraft.util.Identifier.tryParse(id.contains(":") ? id : "minecraft:" + id);
            if (i != null) C().ahKeyword = net.minecraft.registry.Registries.ITEM.get(i).getName().getString().toLowerCase();
        }))));
        m.add(() -> { kw[0] = new TextFieldWidget(mc().textRenderer, 0, 0, 220, 20, Text.literal("kw")); kw[0].setPlaceholder(Text.literal("Tên món (vd: diamond)")); kw[0].setText(C().ahKeyword); return kw[0]; });
        m.add(() -> { pr[0] = new TextFieldWidget(mc().textRenderer, 0, 0, 220, 20, Text.literal("pr")); pr[0].setPlaceholder(Text.literal("Giá tối đa (0 = không giới hạn)")); pr[0].setText(C().ahMaxPrice == 0 ? "" : String.valueOf((long) C().ahMaxPrice)); return pr[0]; });
        m.add(Pages.button("💾 Lưu từ khóa + giá", () -> {
            C().ahKeyword = kw[0].getText().trim();
            try { C().ahMaxPrice = pr[0].getText().isBlank() ? 0 : Double.parseDouble(pr[0].getText().trim()); } catch (Exception e) { C().ahMaxPrice = 0; }
            Config.save(); Util.msg("Đã lưu /ah");
        }));
        m.add(Pages.slider("Chu kỳ mở /ah (tick)", 20, 400, true, () -> C().ahInterval, v -> C().ahInterval = (int) v));
        return new MenuScreen("Auto /ah", p, m);
    }

    static Screen sus(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(Pages.toggle("Hiện chunk đáng nghi (đỏ)", () -> C().susOn, v -> C().susOn = v));
        m.add(Pages.slider("Số block người đặt tối thiểu / chunk", 10, 300, true, () -> C().susMin, v -> C().susMin = (int) v));
        m.add(Pages.slider("Sâu dưới mặt đất (block)", 1, 20, true, () -> C().susDepth, v -> C().susDepth = (int) v));
        m.add(Pages.slider("Độ đậm khối đặc (ESP)", 10, 200, true, () -> C().espAlpha, v -> C().espAlpha = (int) v));
        return new MenuScreen("Sus chunk", p, m);
    }

    static Screen chat(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(Pages.toggle("Dịch chat Anh -> Việt (hiện thêm dòng)", () -> C().chatIn, v -> C().chatIn = v));
        m.add(Pages.toggle("Tin gõ tiếng Việt (có dấu) -> gửi tiếng Anh", () -> C().chatOut, v -> C().chatOut = v));
        return new MenuScreen("Dịch chat", p, m);
    }

    static Screen shock(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(Pages.toggle("Shockwave (sóng xung kích)", () -> C().shockOn, v -> C().shockOn = v));
        m.add(Pages.toggle("Khi nhảy lên", () -> C().shockJump, v -> C().shockJump = v));
        m.add(Pages.toggle("Khi tiếp đất", () -> C().shockLand, v -> C().shockLand = v));
        m.add(Pages.toggle("Dùng khối (block) thay vì hạt màu", () -> C().shockBlock, v -> C().shockBlock = v));
        m.add(Pages.color("hạt (khi không dùng khối)", () -> C().shockColor, v -> C().shockColor = v));
        m.add(Pages.slider("Bán kính", 1, 12, false, () -> C().shockRadius, v -> C().shockRadius = v));
        m.add(Pages.slider("Độ cao nâng lên", 0.2, 4, false, () -> C().shockHeight, v -> C().shockHeight = v));
        m.add(Pages.slider("Thời gian (tick)", 4, 60, true, () -> C().shockTicks, v -> C().shockTicks = (int) v));
        m.add(Pages.slider("Rơi tối thiểu để nổ (block)", 0, 10, false, () -> C().shockMinFall, v -> C().shockMinFall = v));
        return new MenuScreen("Shockwave", p, m);
    }

    static Screen trail(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(Pages.toggle("Trail (vệt đuôi)", () -> C().trailOn, v -> C().trailOn = v));
        m.add(Pages.toggle("Cầu vồng (chroma)", () -> C().trailChroma, v -> C().trailChroma = v));
        m.add(Pages.cycle("Vị trí vệt", new String[]{"Dưới chân", "Giữa người", "Trên đầu"}, () -> C().trailPos, v -> C().trailPos = v));
        m.add(Pages.color("đầu vệt (đậm)", () -> C().trailColor1, v -> C().trailColor1 = v));
        m.add(Pages.color("cuối vệt (nhạt)", () -> C().trailColor2, v -> C().trailColor2 = v));
        m.add(Pages.slider("Độ dài (tick)", 8, 120, true, () -> C().trailLen, v -> C().trailLen = (int) v));
        m.add(Pages.slider("Độ đậm ở đầu", 20, 255, true, () -> C().trailAlpha, v -> C().trailAlpha = (int) v));
        m.add(Pages.slider("Chiều cao vệt", 0.1, 2, false, () -> C().trailHeight, v -> C().trailHeight = v));
        return new MenuScreen("Trail", p, m);
    }

    static Screen visual(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(Pages.toggle("Chroma toàn client (ESP, chữ, hạt)", () -> C().chroma, v -> C().chroma = v));
        m.add(Pages.toggle("Đổi giờ trong game (bầu trời sáng/tối)", () -> C().skyOn, v -> C().skyOn = v));
        m.add(Pages.slider("Giờ (0 sáng, 6000 trưa, 13000 tối, 18000 đêm)", 0, 24000, true, () -> C().skyTime, v -> C().skyTime = (int) v));
        m.add(Pages.toggle("Bầu trời ảo (màu tùy chỉnh)", () -> C().skyColorOn, v -> C().skyColorOn = v));
        m.add(Pages.color("bầu trời (trên cao)", () -> C().skyTopColor, v -> C().skyTopColor = v));
        m.add(Pages.color("bầu trời (chân trời)", () -> C().skyHorizonColor, v -> C().skyHorizonColor = v));
        return new MenuScreen("Hiển thị", p, m);
    }

    static Screen hud(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(Pages.toggle("FPS (hiện cả FPS tối đa)", () -> C().hudFps, v -> C().hudFps = v));
        m.add(Pages.toggle("Ping", () -> C().hudPing, v -> C().hudPing = v));
        m.add(Pages.toggle("RAM", () -> C().hudRam, v -> C().hudRam = v));
        m.add(Pages.toggle("Tọa độ", () -> C().hudCoords, v -> C().hudCoords = v));
        m.add(Pages.toggle("Keystrokes (WASD + chuột + CPS)", () -> C().hudKeys, v -> C().hudKeys = v));
        m.add(Pages.toggle("Hiệu ứng thuốc", () -> C().hudPotion, v -> C().hudPotion = v));
        m.add(Pages.toggle("Giáp (độ bền)", () -> C().hudArmor, v -> C().hudArmor = v));
        m.add(Pages.toggle("Combo counter", () -> C().hudCombo, v -> C().hudCombo = v));
        m.add(Pages.toggle("Đếm Totem (còn / đã nổ)", () -> C().hudTotem, v -> C().hudTotem = v));
        m.add(Pages.toggle("Danh sách module đang bật", () -> C().hudArray, v -> C().hudArray = v));
        m.add(Pages.color("chữ HUD", () -> C().hudColor, v -> C().hudColor = v));
        return new MenuScreen("HUD thông tin", p, m);
    }

    static Screen combo(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(Pages.button("▶ Chạy combo ngay (nhìn vào block)", () -> { mc().setScreen(null); AnchorCombo.start(mc()); }));
        m.add(Pages.toggle("Đặt obsidian chắn trước mình", () -> C().comboObs, v -> C().comboObs = v));
        m.add(Pages.slider("Độ trễ giữa các bước (tick)", 0, 10, true, () -> C().comboDelay, v -> C().comboDelay = (int) v));
        return new MenuScreen("Combo Anchor 1 phím (J)", p, m);
    }

    static Screen vel(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(Pages.toggle("Velocity (giảm knockback)", () -> C().velOn, v -> C().velOn = v));
        m.add(Pages.slider("Giữ lại % đẩy ngang", 0, 100, true, () -> C().velH, v -> C().velH = (int) v));
        m.add(Pages.slider("Giữ lại % đẩy dọc", 0, 100, true, () -> C().velV, v -> C().velV = (int) v));
        return new MenuScreen("Velocity", p, m);
    }

    static Screen util(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(Pages.toggle("Chặn mở rương/hopper/shulker/thùng (shift để mở)", () -> C().noOpenContainer, v -> C().noOpenContainer = v));
        m.add(Pages.toggle("Macro Crystal (cầm crystal + giữ chuột phải vào obsidian)", () -> C().crystalMacro, v -> C().crystalMacro = v));
        m.add(Pages.slider("Macro Crystal: delay nổ (tick)", 0, 6, true, () -> C().macroDelay, v -> C().macroDelay = (int) v));
        m.add(Pages.toggle("Macro Crystal: tự đặt lại liên tục", () -> C().macroPlace, v -> C().macroPlace = v));
        m.add(Pages.slider("Macro Crystal: đập tối đa (crystal / tick)", 1, 30, true, () -> C().macroPerTick, v -> C().macroPerTick = (int) v));
        m.add(Pages.toggle("Macro Crystal: đập mọi crystal trong tầm", () -> C().macroAll, v -> C().macroAll = v));
        m.add(Pages.toggle("Anchor Shield (nổ anchor -> tự chắn 1 obsidian)", () -> C().anchorShield, v -> C().anchorShield = v));
        return new MenuScreen("Tiện ích", p, m);
    }

    static final String[] LOG = {
        "§dv2.11§f  Dò căn cứ: Sus ESP, Spawner ESP, Hole ESP, Lightfinder, Chunk Finder v2 (hiện tọa độ)",
        "  + Cài đặt module (chuột phải): phím tắt riêng, Alpha, Min/Max Y, bộ lọc block, chế độ Safe/Risk/Unsafe",
        "§dv2.10.1§f  Fix: obsidian chỉ đặt lúc sắp nổ, không đặt ngay khi đặt anchor",
        "§dv2.10§f  Anchor Shield: bấm nổ anchor (1-4 glowstone) -> đặt ngay 1 obsidian phía mình, không chắn đối thủ",
        "  + Macro Crystal: đập tới 30 crystal / tick, đặt lại ngay trong tick",
        "§dv2.9§f  Bỏ Spin Bot. Radar: icon block 2D, xuyên tường, báo trên/dưới",
        "  + Mace: thả rơi thẳng theo đà (hết bị bật qua đầu), chân ngang đầu là đánh luôn",
        "  + Macro tự thiết kế (K), trượt mượt khi tp/pearl, âm bàn phím",
        "§dv2.8§f  Spin Bot (đã gỡ ở v2.9)",
        "§dv2.7§f  Bảng màu (chuột phải kéo/click), ô nhập có hình 2D (gõ log -> hiện hết)",
        "  + Chặn mở rương/hopper/shulker, Macro Crystal, Tâm tự vẽ, Sky ảo",
        "  + Trail đầu/giữa/chân, Shockwave khối nhô lên rớt chậm",
        "  + Fix Safe Anchor (đúng 1 obsidian), Elytra Mace chuỗi đập, bỏ Mace liên tục",
        "§dv2.6§f  Hit Splash, Target ESP, Radiance, Afterglow, lưới Cyberspace,",
        "  + Shockwave ô sáng, Bridge, Name Tags, vòng tâm ngắm, đếm Totem",
        "§dv2.5§f  Học từ PURXIY: Jump Circle, Ripple, Block Outline,",
        "  + Place Animation, Triggerbot, Hit Select, Silent Aura",
        "  + Configs (lưu/tải/copy), HUD: CPS, thuốc, giáp, combo, module",
        "§dv2.4§f  Menu chia hàng + vuốt ngang, animation tiêu đề",
        "  + Shockwave, Trail, Chroma, đổi giờ, Velocity",
        "  + Combo Anchor 1 phím (J), HUD FPS/Ping/RAM/phím",
        "§dv2.3§f  Auto PvP, Tự đào, Auto /ah, Sus chunk, Dịch chat",
        "  + Mace liên tục, xây theo hàng, đặt theo hướng nhìn",
        "  + Fix lag Block ESP, chỉnh độ đậm block ESP",
        "§dv2.2§f  Bản gốc: Elytra Mace, Crystal, Anchor, ESP, Printer",
    };

    static Screen devlog(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        for (String s : LOG) m.add(() -> {
            var b = net.minecraft.client.gui.widget.ButtonWidget.builder(Text.literal(s), x -> {}).dimensions(0, 0, 220, 20).build();
            b.active = false; return b;
        });
        return new MenuScreen("Nhật ký cập nhật (Dev log)", p, m);
    }

    static Screen fx(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(Pages.toggle("Jump Circle (vòng khi nhảy)", () -> C().ringJump, v -> C().ringJump = v));
        m.add(Pages.toggle("Ripple (vòng sáng khi đánh trúng)", () -> C().ringHit, v -> C().ringHit = v));
        m.add(Pages.color("vòng nhảy", () -> C().ringColor, v -> C().ringColor = v));
        m.add(Pages.color("vòng đánh", () -> C().ringHitColor, v -> C().ringHitColor = v));
        m.add(Pages.slider("Cỡ vòng nhảy", 1, 8, false, () -> C().ringSize, v -> C().ringSize = v));
        m.add(Pages.slider("Thời gian vòng (tick)", 6, 40, true, () -> C().ringTicks, v -> C().ringTicks = (int) v));
        m.add(Pages.toggle("Block Outline (khung trượt mượt)", () -> C().glideOn, v -> C().glideOn = v));
        m.add(Pages.color("khung block", () -> C().glideColor, v -> C().glideColor = v));
        m.add(Pages.slider("Tốc độ trượt khung (%)", 5, 100, true, () -> C().glideSpeed, v -> C().glideSpeed = (int) v));
        m.add(Pages.toggle("Place Animation (block đặt lớn dần)", () -> C().placeAnimOn, v -> C().placeAnimOn = v));
        m.add(Pages.color("hiệu ứng đặt", () -> C().placeColor, v -> C().placeColor = v));
        m.add(Pages.slider("Thời gian đặt (tick)", 3, 30, true, () -> C().placeTicks, v -> C().placeTicks = (int) v));
        return new MenuScreen("Hiệu ứng", p, m);
    }

    static Screen combat2(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(Pages.toggle("Triggerbot (đánh khi tâm ngắm trúng)", () -> C().trigOn, v -> C().trigOn = v));
        m.add(Pages.toggle("Hit Select (chỉ cho đánh khi cooldown đủ)", () -> C().hitSelect, v -> C().hitSelect = v));
        m.add(Pages.slider("Cooldown tối thiểu (%)", 50, 100, true, () -> C().hitSelectMin, v -> C().hitSelectMin = (int) v));
        m.add(Pages.toggle("Silent Aura (Auto PvP không xoay màn hình)", () -> C().pvpSilent, v -> C().pvpSilent = v));
        return new MenuScreen("Combat+", p, m);
    }

    static Screen configs(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(Pages.button("💾 Lưu config mới", () -> {
            try {
                java.nio.file.Files.createDirectories(Config.dir());
                String n = "cfg-" + new java.text.SimpleDateFormat("MMdd-HHmmss").format(new java.util.Date());
                java.nio.file.Files.writeString(Config.dir().resolve(n + ".json"), Config.exportJson());
                Util.msg("Đã lưu " + n);
            } catch (Exception e) { Util.warn("Lưu lỗi: " + e.getMessage()); }
            mc().setScreen(configs(p));
        }));
        m.add(Pages.button("📋 Copy config vào clipboard (để gửi bạn)", () -> { mc().keyboard.setClipboard(Config.exportJson()); Util.msg("Đã copy config"); }));
        m.add(Pages.button("📥 Dán config từ clipboard", () -> {
            Util.msg(Config.importJson(mc().keyboard.getClipboard()) ? "Đã nạp config" : "§cClipboard không phải config hợp lệ");
            mc().setScreen(Pages.main(null));
        }));
        try {
            if (java.nio.file.Files.isDirectory(Config.dir())) try (var st = java.nio.file.Files.list(Config.dir())) {
                for (var f : st.filter(x -> x.toString().endsWith(".json")).sorted().toList()) {
                    String name = f.getFileName().toString().replace(".json", "");
                    m.add(Pages.button("▶ Tải: " + name, () -> {
                        try { Config.importJson(java.nio.file.Files.readString(f)); Util.msg("Đã tải " + name); } catch (Exception e) { Util.warn("Lỗi tải"); }
                        mc().setScreen(Pages.main(null));
                    }));
                    m.add(Pages.button("🗑 Xóa: " + name, () -> { try { java.nio.file.Files.deleteIfExists(f); } catch (Exception ignored) {} mc().setScreen(configs(p)); }));
                }
            }
        } catch (Exception ignored) {}
        return new MenuScreen("Configs", p, m);
    }

    static Screen extra(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(Pages.toggle("Hit Splash (hạt màu khi đánh trúng)", () -> C().hitSplash, v -> C().hitSplash = v));
        m.add(Pages.color("hạt Hit Splash / Afterglow", () -> C().splashColor, v -> C().splashColor = v));
        m.add(Pages.toggle("Afterglow (hạt bay lên khi hạ gục)", () -> C().afterglow, v -> C().afterglow = v));
        m.add(Pages.toggle("Target ESP (vòng quanh mục tiêu)", () -> C().targetEsp, v -> C().targetEsp = v));
        m.add(Pages.color("Target ESP", () -> C().targetColor, v -> C().targetColor = v));
        m.add(Pages.toggle("Radiance (vầng sáng quanh người chơi)", () -> C().radiance, v -> C().radiance = v));
        m.add(Pages.color("Radiance", () -> C().radianceColor, v -> C().radianceColor = v));
        m.add(Pages.toggle("Lưới Cyberspace dưới chân", () -> C().gridOn, v -> C().gridOn = v));
        m.add(Pages.color("lưới", () -> C().gridColor, v -> C().gridColor = v));
        m.add(Pages.slider("Bán kính lưới", 4, 20, true, () -> C().gridRadius, v -> C().gridRadius = (int) v));
        m.add(Pages.toggle("Shockwave ô sáng khi tiếp đất", () -> C().tileOn, v -> C().tileOn = v));
        m.add(Pages.color("ô sáng", () -> C().tileColor, v -> C().tileColor = v));
        m.add(Pages.slider("Bán kính ô sáng", 3, 12, true, () -> C().tileRadius, v -> C().tileRadius = (int) v));
        m.add(Pages.toggle("Vòng quanh tâm ngắm", () -> C().crossRing, v -> C().crossRing = v));
        m.add(Pages.toggle("Name Tags (tên + máu + khoảng cách)", () -> C().nameTags, v -> C().nameTags = v));
        m.add(Pages.toggle("Bridge (tự ngồi ở mép + đặt block)", () -> C().bridgeOn, v -> C().bridgeOn = v));
        return new MenuScreen("Hiệu ứng 2", p, m);
    }
}
