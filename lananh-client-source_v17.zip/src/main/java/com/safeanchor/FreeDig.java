package com.safeanchor;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.option.Perspective;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/**
 * FreeDig: bật module trong menu -> camera thành FREECAM (bay tự do, người chơi đứng yên).
 * Bay tới góc TRÊN cần đào, bấm phím [Chọn góc đào] -> góc 1; bay xuống góc DƯỚI đối diện, bấm lần nữa -> góc 2.
 * Vùng chọn hiện khung neon vàng, rồi bot tự đào hết vùng từ tầng trên xuống (AutoMine chế độ vùng). Bấm phím lần nữa khi đang đào = dừng.
 * Đổi phím trong Cài đặt -> Điều khiển -> "LAN ANH CLIENT".
 */
public class FreeDig {
    public static final KeyBinding KEY = KeyBindingHelper.registerKeyBinding(
            new KeyBinding("key.safeanchor.dig", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_G, "category.safeanchor"));

    public static boolean on;           // module bật
    public static boolean cam;          // đang ở camera tự do
    public static int phase;            // 0 = chờ góc 1, 1 = chờ góc 2, 2 = đang đào
    public static BlockPos p1, p2, hover;
    public static Vec3d pos = Vec3d.ZERO;
    public static float yaw, pitch;
    static float sYaw, sPitch;
    static long last;
    static Perspective savedPersp = Perspective.FIRST_PERSON;

    public static void init() { /* chạm vào class để đăng ký phím */ }

    // ---------- bật / tắt ----------
    public static void setOn(boolean v) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (v == on) return;
        if (v) {
            if (mc.player == null) { Util.msg("Vào thế giới rồi mới bật FreeDig"); return; }
            on = true; phase = 0; p1 = p2 = null;
            enterCam(mc);
            Util.msg("FreeDig: bay tới góc TRÊN rồi bấm [" + KEY.getBoundKeyLocalizedText().getString() + "]");
        } else {
            on = false; phase = 0; p1 = p2 = null;
            AutoMine.stopArea(mc);
            exitCam(mc);
        }
    }

    static void enterCam(MinecraftClient mc) {
        var p = mc.player;
        pos = p.getEyePos(); yaw = p.getYaw(); pitch = p.getPitch(); sYaw = yaw; sPitch = pitch;
        savedPersp = mc.options.getPerspective();
        mc.options.setPerspective(Perspective.THIRD_PERSON_BACK);      // thấy luôn người mình đứng ở đâu
        last = System.nanoTime(); cam = true;
    }

    static void exitCam(MinecraftClient mc) {
        if (!cam) return;
        cam = false;
        mc.options.setPerspective(savedPersp);
        if (mc.player != null) { mc.player.setYaw(sYaw); mc.player.setPitch(sPitch); }
    }

    static boolean held(long h, KeyBinding kb) {
        int code = KeyBindingHelper.getBoundKeyOf(kb).getCode();
        return code >= 0 && InputUtil.isKeyPressed(h, code);
    }

    /** Gọi mỗi frame từ CameraMixin: chuột xoay camera, phím WASD / Space / Shift bay. */
    public static void frame(MinecraftClient mc) {
        var p = mc.player;
        if (p == null || !cam) return;
        long now = System.nanoTime();
        double dt = Math.min(0.1, (now - last) / 1e9); last = now;
        yaw += p.getYaw() - sYaw;                                           // chuột xoay camera, giữ nguyên hướng của người chơi
        pitch = MathHelper.clamp(pitch + (p.getPitch() - sPitch), -90f, 90f);
        p.setYaw(sYaw); p.setPitch(sPitch);
        if (mc.currentScreen != null) return;
        long h = mc.getWindow().getHandle();
        double yr = Math.toRadians(yaw), sin = Math.sin(yr), cos = Math.cos(yr), mx = 0, mz = 0, my = 0;
        if (held(h, mc.options.forwardKey)) { mx -= sin; mz += cos; }
        if (held(h, mc.options.backKey)) { mx += sin; mz -= cos; }
        if (held(h, mc.options.leftKey)) { mx += cos; mz += sin; }
        if (held(h, mc.options.rightKey)) { mx -= cos; mz -= sin; }
        if (held(h, mc.options.jumpKey)) my += 1;
        if (held(h, mc.options.sneakKey)) my -= 1;
        double len = Math.hypot(mx, mz); if (len > 1) { mx /= len; mz /= len; }
        double sp = Config.I.fdSpeed * (held(h, mc.options.sprintKey) ? 3 : 1);
        pos = pos.add(mx * sp * dt, my * sp * dt, mz * sp * dt);
        Vec3d pp = p.getPos();                                              // không bay xa quá (chunk ngoài tầm tải không có gì để chọn)
        double r = Config.I.fdRange;
        pos = new Vec3d(MathHelper.clamp(pos.x, pp.x - r, pp.x + r), MathHelper.clamp(pos.y, pp.y - r, pp.y + r), MathHelper.clamp(pos.z, pp.z - r, pp.z + r));
    }

    /** Đầu mỗi tick: chặn phím di chuyển / đánh / dùng để người chơi đứng yên trong lúc freecam. */
    public static void startTick(MinecraftClient mc) {
        if (!cam || mc.player == null) return;
        var o = mc.options;
        o.forwardKey.setPressed(false); o.backKey.setPressed(false); o.leftKey.setPressed(false); o.rightKey.setPressed(false);
        o.jumpKey.setPressed(false); o.sneakKey.setPressed(false); o.sprintKey.setPressed(false);
        o.attackKey.setPressed(false); o.useKey.setPressed(false);
        while (o.attackKey.wasPressed()) { }
        while (o.useKey.wasPressed()) { }
    }

    // ---------- tick ----------
    public static void tick(MinecraftClient mc) {
        if (!on) return;
        if (mc.player == null || mc.world == null) { setOn(false); return; }
        while (KEY.wasPressed()) press(mc);
        if (cam) {
            Vec3d dir = Vec3d.fromPolar(pitch, yaw);
            var hit = mc.world.raycast(new RaycastContext(pos, pos.add(dir.multiply(160)), RaycastContext.ShapeType.OUTLINE, RaycastContext.FluidHandling.NONE, mc.player));
            hover = hit.getType() == HitResult.Type.BLOCK ? hit.getBlockPos() : null;
        }
        if (phase == 2 && !AutoMine.areaActive()) {                         // đào xong
            Util.msg("FreeDig: đào xong vùng");
            phase = 0; p1 = p2 = null;
            enterCam(mc);
        }
    }

    static void press(MinecraftClient mc) {
        if (phase == 2) {                                                   // đang đào -> dừng
            AutoMine.stopArea(mc);
            phase = 0; p1 = p2 = null;
            enterCam(mc);
            Util.msg("FreeDig: đã dừng, chọn vùng mới");
            return;
        }
        if (hover == null) { Util.warn("Ngắm vào 1 block rồi bấm"); return; }
        if (phase == 0) {
            p1 = hover; phase = 1;
            Util.msg("Góc 1 = " + p1.toShortString() + " - bay xuống góc DƯỚI đối diện rồi bấm lại");
        } else {
            p2 = hover;
            BlockPos a = new BlockPos(Math.min(p1.getX(), p2.getX()), Math.min(p1.getY(), p2.getY()), Math.min(p1.getZ(), p2.getZ()));
            BlockPos b = new BlockPos(Math.max(p1.getX(), p2.getX()), Math.max(p1.getY(), p2.getY()), Math.max(p1.getZ(), p2.getZ()));
            long vol = (long) (b.getX() - a.getX() + 1) * (b.getY() - a.getY() + 1) * (b.getZ() - a.getZ() + 1);
            if (vol > 600000) { Util.warn("Vùng quá lớn (" + vol + " block), chọn nhỏ hơn"); p2 = null; return; }
            phase = 2;
            exitCam(mc);
            AutoMine.startArea(a, b);
            Util.msg("FreeDig: bắt đầu đào " + vol + " block, tầng trên xuống dưới");
        }
    }

    // ---------- HUD + vẽ ----------
    public static void hud(DrawContext ctx) {
        if (!on) return;
        var mc = MinecraftClient.getInstance();
        String k = KEY.getBoundKeyLocalizedText().getString();
        String t = phase == 0 ? "FreeDig: bay tới góc TRÊN, bấm [" + k + "]"
                : phase == 1 ? "FreeDig: bay xuống góc DƯỚI đối diện, bấm [" + k + "]"
                : "FreeDig: đang đào (bấm [" + k + "] để dừng)";
        int w = mc.textRenderer.getWidth(t), x = (mc.getWindow().getScaledWidth() - w) / 2;
        ctx.fill(x - 4, 18, x + w + 4, 31, 0x90000000);
        ctx.drawText(mc.textRenderer, t, x, 21, 0xFFFFE040, true);
    }

    public static void render(WorldRenderContext ctx) {
        if (!on) return;
        List<BaseScan.Draw> list = new ArrayList<>();
        if (hover != null && cam) list.add(new BaseScan.Draw(new Box(hover), 0xFFFFFF, 70));
        if (p1 != null) {
            BlockPos a = p1, b = (phase == 1 && hover != null) ? hover : (p2 != null ? p2 : p1);
            list.add(new BaseScan.Draw(new Box(Math.min(a.getX(), b.getX()), Math.min(a.getY(), b.getY()), Math.min(a.getZ(), b.getZ()),
                    Math.max(a.getX(), b.getX()) + 1, Math.max(a.getY(), b.getY()) + 1, Math.max(a.getZ(), b.getZ()) + 1), 0xE6FF00, 26));   // khung neon vàng
        }
        if (phase == 2 && AutoMine.areaActive()) {
            BlockPos a = AutoMine.areaMin, b = AutoMine.areaMax;
            list.add(new BaseScan.Draw(new Box(a.getX(), a.getY(), a.getZ(), b.getX() + 1, b.getY() + 1, b.getZ() + 1), 0xE6FF00, 14));
            int ly = AutoMine.layerY;                                       // tầng đang đào
            if (ly >= a.getY() && ly <= b.getY()) list.add(new BaseScan.Draw(new Box(a.getX(), ly, a.getZ(), b.getX() + 1, ly + 1, b.getZ() + 1), 0x40FF80, 45));
        }
        BaseScan.paint(ctx, list);
    }
}
