package com.safeanchor;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;

import java.util.*;

/** Quét block quanh người chơi (quặng / tiện ích / đặc biệt / block tùy chỉnh) – mỗi tick quét 1 chunk. */
public class BlockEsp {
    public record Hit(BlockPos pos, int color) {}

    static final String[] ORES = {"coal_ore","iron_ore","copper_ore","gold_ore","redstone_ore","lapis_ore","diamond_ore","emerald_ore",
            "deepslate_coal_ore","deepslate_iron_ore","deepslate_copper_ore","deepslate_gold_ore","deepslate_redstone_ore",
            "deepslate_lapis_ore","deepslate_diamond_ore","deepslate_emerald_ore","nether_gold_ore","nether_quartz_ore","ancient_debris"};
    static final String[] UTILITY = {"furnace","blast_furnace","smoker","crafting_table","enchanting_table","anvil","brewing_stand","beacon","hopper"};
    static final String[] SPECIAL = {"spawner","trial_spawner","vault","end_portal_frame","respawn_anchor","obsidian"};

    static final Map<Long, List<Hit>> CACHE = new HashMap<>();
    static final Map<Block, Integer> wanted = new HashMap<>();
    static int sig; static int round;
    static final List<Hit> out = new ArrayList<>();

    static int signature() {
        Config c = Config.I;
        return Objects.hash(c.espBlkOres, c.espBlkUtility, c.espBlkSpecial, c.espBlkOreColor, c.espBlkUtilityColor,
                c.espBlkSpecialColor, c.espBlkCustomColor, c.espBlkCustom);
    }

    static void rebuild() {
        wanted.clear(); CACHE.clear();
        Config c = Config.I;
        if (c.espBlkOres) for (String s : ORES) add(s, c.espBlkOreColor);
        if (c.espBlkUtility) for (String s : UTILITY) add(s, c.espBlkUtilityColor);
        if (c.espBlkSpecial) for (String s : SPECIAL) add(s, c.espBlkSpecialColor);
        for (String s : c.espBlkCustom) add(s, c.espBlkCustomColor);
    }
    static void add(String id, int color) {
        Identifier i = Identifier.tryParse(id.contains(":") ? id : "minecraft:" + id);
        if (i == null) return;
        Block b = Registries.BLOCK.get(i);
        if (b != Blocks.AIR) wanted.put(b, color);
    }

    public static List<Hit> hits() { return out; }

    static final Map<Long, Integer> scanTick = new HashMap<>();
    static int tickN;

    public static void tick(MinecraftClient mc) {
        Config c = Config.I;
        out.clear();
        if (mc.player == null || mc.world == null || !(c.espBlocks || c.radarOn)) return;
        if (!c.espBlocks && !(c.radarOn && c.radarBlocks)) return;
        int s = signature();
        if (s != sig) { sig = s; rebuild(); scanTick.clear(); }
        if (wanted.isEmpty()) return;
        tickN++;

        int pcx = mc.player.getBlockX() >> 4, pcz = mc.player.getBlockZ() >> 4;
        int rad = (int) Math.ceil(Math.max(c.espBlkRange, c.radarRange) / 16.0);
        int side = rad * 2 + 1;
        // mỗi tick chỉ quét 1 chunk (chunk nào chưa quét hoặc đã quá 200 tick), bỏ qua section không có block cần tìm
        for (int tries = 0; tries < side * side; tries++) {
            round = (round + 1) % (side * side);
            int cx = pcx - rad + round % side, cz = pcz - rad + round / side;
            long key = ((long) cx << 32) ^ (cz & 0xffffffffL);
            Integer last = scanTick.get(key);
            if (last != null && tickN - last < 200) continue;
            WorldChunk ch = mc.world.getChunkManager().getWorldChunk(cx, cz);
            if (ch == null) { CACHE.remove(key); continue; }
            scanTick.put(key, tickN);
            List<Hit> list = new ArrayList<>();
            ChunkSection[] secs = ch.getSectionArray();
            for (int i = 0; i < secs.length && list.size() <= 600; i++) {
                if (secs[i].isEmpty() || !secs[i].hasAny(st -> wanted.containsKey(st.getBlock()))) continue;
                int baseY = (ch.getBottomSectionCoord() + i) << 4;
                for (int x = 0; x < 16; x++) for (int y = 0; y < 16; y++) for (int z = 0; z < 16; z++) {
                    Integer col = wanted.get(secs[i].getBlockState(x, y, z).getBlock());
                    if (col != null) list.add(new Hit(new BlockPos((cx << 4) + x, baseY + y, (cz << 4) + z), col));
                }
            }
            CACHE.put(key, list);
            break;
        }
        double r2 = Math.max(c.espBlkRange, c.radarRange); r2 *= r2;
        for (var list : CACHE.values()) for (Hit h : list) {
            if (Vec3d.ofCenter(h.pos()).squaredDistanceTo(mc.player.getPos()) <= r2) out.add(h);
            if (out.size() > 2500) return;
        }
    }
}
