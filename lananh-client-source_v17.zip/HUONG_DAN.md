# LAN ANH CLIENT - HƯỚNG DẪN NHANH

Mở menu: **Right Shift** (hoặc Insert). Chạm trái vào module = bật/tắt, chạm phải = cài đặt. Thanh trên cùng chọn nhóm. Nút "Hướng dẫn" và "Menu cũ" ở góc trên phải.
Không cần vào game: Màn hình chính -> Mods (Mod Menu) -> "lan anh client" -> nút cài đặt.

## Đào hầm thẳng (TunnelDig, tab WORLD)
1. Đứng ở đầu hầm, nhìn theo hướng muốn đào, bật TunnelDig.
2. Chuột phải để chỉnh:
   - **Kiểu: Cúp thường** = hầm 1x2, đào từng block bằng cúp.
   - **Kiểu: Amethyst 3x3** = đứng GIỮA, đào mặt 3x3 phía trước (hàng chân + 2 hàng trên, mỗi bên 1 block). Đào block giữa trước, cúp amethyst phá luôn 9 khối; ô nào còn sót mod đào nốt.
   - **Hướng**: Theo nhìn / Bắc / Nam / Đông / Tây / Xuống (đào bậc thang đi xuống).
   - **Vá sàn**: sàn phía trước bị hở thì cúi xuống đặt 1 block thường rồi mới bước.
   - **Né lava**: gặp lava thì dừng. **Dài**: đào bao nhiêu block rồi dừng (0 = mãi).
3. Tắt module để dừng. Mod tự cầm đúng dụng cụ.

## Tìm chỗ xây base không hang (BaseFinder, tab WORLD)
1. Chuột phải BaseFinder -> bật "Mở bảng nhập X Z".
2. Nhập X, Z (hoặc "Lấy tọa độ của tôi"), Y xây, kích thước (hoặc "Theo schematic"), "Xa hang (chunk)", "Dung sai hang". Bấm **TÌM**.
3. Mod chỉ tính hang từ tầng đá sâu (deepslate, Y <= "Hang từ Y") trở xuống, hang trong tầng xây và hang trên đầu tính nặng hơn.
4. Kết quả: 4 trụ sáng ở 4 góc khu xây, khung vàng = khối khu xây, ô đỏ = chunk có hang. Bấm XÓA để xóa.
- Chỉ quét được chunk đã tải: đứng gần tọa độ cần dò, nên để render distance >= 16.

## Freecam chọn vùng đào (FreeDig, tab WORLD)
1. Bật FreeDig: camera bay tự do (WASD, Space lên, Shift xuống, Ctrl nhanh), người chơi đứng yên.
2. Bay tới góc TRÊN cần đào, ngắm vào block, bấm phím **G** (đổi trong Điều khiển -> LAN ANH CLIENT).
3. Bay xuống góc DƯỚI đối diện, bấm G lần nữa. Bot tự đào cả vùng từ tầng trên xuống (khung neon vàng, tầng đang đào tô xanh).
4. Bấm G khi đang đào = dừng. Tắt module = hủy hết.

## Dò căn cứ
- **SusESP**: block người đặt dưới lòng đất (đã bỏ block của Trail Ruins). Chuột phải: Min/Max Y, Alpha, bộ lọc loại block.
- **SpawnerESP**: lồng spawner (mặc định ẩn lồng quái tự nhiên: dungeon, mineshaft, trial chamber).
- **HoleESP**, **Lightfinder**, **ChunkFinder** (hiện tọa độ chunk đáng nghi trên HUD).

## Elytra Mace
- Kiểu **Thả rơi** hoặc **Lao pháo**; Đuổi, Bay tìm, Khóa 1 mục tiêu; chuột phải vào ElytraMace có màn hình nhỏ minh họa mình và BOT.

## Âm thanh bàn phím (KeySound)
- Bật module KeySound. **Loại**: 7 bộ Cherry MX (Brown PBT, Brown ABS, Red ABS, Black PBT, Black ABS, Blue ABS, Blue ABS 2).
- **Toàn game**: Tắt / Giao diện (mọi tiếng menu, nút, cài đặt) / Mọi tiếng (mọi thứ trong Minecraft, trừ nhạc nền) đều đổi thành tiếng phím.

## Dịch chat (Translate)
- Gửi: gõ tiếng Việt -> tự dịch sang tiếng Anh rồi mới gửi. Nhận: chat người khác được đổi thẳng sang tiếng Việt.
- Bật module Translate, chuột phải để chọn ngôn ngữ.

## Menu
- Module **Giao diện**: nền Tối / Màu / Gradient / Ảnh (PNG tại config/lananh-bg.png), độ tối, khung giữa, **Trong suốt %**.
